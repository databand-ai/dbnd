from dbnd import dbnd_main


if __name__ == "__main__":
    dbnd_main()
